const express=require('express');
const http=require('http');
const {Server}=require('socket.io');
const path=require('path');
const app=express();
const server=http.createServer(app);
const io=new Server(server);
app.use(express.json());
app.use(express.static(path.join(__dirname,'public')));
let auction={active:false,item:'Mystery Item #01',highest:0,bidder:'',endsAt:0,bids:[]};
function state(){return auction}
function broadcast(){io.emit('auction:state',state())}
app.get('/api/auction',(req,res)=>res.json(state()));
app.post('/api/auction/start',(req,res)=>{const {item='Mystery Item #01',start=100,duration=60}=req.body||{};auction={active:true,item,highest:Number(start)||0,bidder:'',endsAt:Date.now()+(Number(duration)||60)*1000,bids:[]};broadcast();res.json(state())});
app.post('/api/auction/end',(req,res)=>{auction.active=false;auction.endsAt=Date.now();broadcast();res.json(state())});
app.post('/api/gift',(req,res)=>{const {username='Anonim',coins=0}=req.body||{};const amount=Number(coins)||0;if(!auction.active)return res.status(400).json({error:'Lelang belum aktif'});if(amount<=0)return res.status(400).json({error:'coins harus > 0'});auction.highest+=amount;auction.bidder=username;auction.bids.push({username,coins:amount,total:auction.highest,at:Date.now()});broadcast();res.json(state())});
io.on('connection',socket=>{socket.emit('auction:state',state())});
setInterval(()=>{if(auction.active&&auction.endsAt&&Date.now()>=auction.endsAt){auction.active=false;broadcast()}},250);
const PORT=process.env.PORT||3000;server.listen(PORT,()=>console.log(`TikAuction running on http://localhost:${PORT}`));
